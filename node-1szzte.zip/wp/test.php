<?php

echo 'abc';

